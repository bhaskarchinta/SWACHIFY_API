﻿namespace Swachify.Api;

public class AdminController
{

}
