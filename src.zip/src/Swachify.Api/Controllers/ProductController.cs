﻿namespace Swachify.Api;

public class ProductController
{

}
